# vue3-ts

## Project setup
```
pnpm install
```

### Compiles and hot-reloads for development
```
pnpm dev
```

### Compiles and minifies for production
```
pnpm build
```


### Customize configuration
See [Configuration Reference](https://vitejs.cn/guide/features.html).
