import 'amfe-flexible';
import '../../vue2/src/main';
