import '../../vue2/src/main';
