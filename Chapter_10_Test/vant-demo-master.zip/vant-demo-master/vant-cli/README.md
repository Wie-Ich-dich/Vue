# Vant Cli 示例

Vant Cli 的基础示例工程，示范通过 Vant Cli 快速搭建一套组件库。

> 技术栈：Vue、Vant Cli
