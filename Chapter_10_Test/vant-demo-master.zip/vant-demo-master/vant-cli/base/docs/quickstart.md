# 快速上手

### 安装

```bash
# 通过 npm 安装
npm i vant -S

# 通过 yarn 安装
yarn add vant
```

### 引入组件

这是一段引入组件的介绍
