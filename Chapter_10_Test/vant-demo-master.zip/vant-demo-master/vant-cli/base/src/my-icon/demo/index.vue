<template>
  <demo-section>
    <demo-block title="基础用法">
      <my-icon name="success" />
    </demo-block>

    <demo-block title="显示红点">
      <my-icon name="success" dot />
    </demo-block>
  </demo-section>
</template>

<style lang="less">
.demo-my-icon {
  .my-icon {
    margin-left: 16px;
  }
}
</style>
