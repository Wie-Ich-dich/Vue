export function foo() {
  return 'bar';
}
