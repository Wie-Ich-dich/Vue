<template>
  <demo-section>
    <demo-block title="基础用法">
      <my-cell title="单元格" />
    </demo-block>

    <demo-block title="显示箭头">
      <my-cell title="单元格" is-link />
    </demo-block>
  </demo-section>
</template>
